import React from "react";
import {
  StyleSheet,
  SafeAreaView,
  View,
  Image,
  Text,
  ViewStyle,
  FlatList,
  TouchableOpacity,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import Constants from "expo-constants";
import { Feather } from "@expo/vector-icons";
import Article from "./Articles";
import axios from 'axios';


// This is item
//import item from "./data";
import data from "./data";

const INSTAGRAM_LOGO =
  "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Instagram_logo.svg/1200px-Instagram_logo.svg.png";

export default function Feed() {
  function renderItem({item}) {
      /* Loop through */
      return <Article item={item} />;
  }

  async function getData() {
    const users = await axios.get('localhost:5000/getAllUsers')
    return (
      <div> {users.map ((i,j)=> {
        return <Article item={j}/>
      })}
      </div>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />

      <View style={styles.header}>
        
        <Text numberOfLines={1} style={styles.hiText}>
              GroupPie.
        </Text>
      </View>
     { getData }
    </SafeAreaView>
  );
}


const BORDER_BOTTOM: ViewStyle = {
  borderBottomWidth: 1,
  borderBottomColor: "#dbdbdb",
};
const TEXT: TextStyle = {
  color: "#dbd",
  textAlign: "center",
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
  },
  hiText: {
      ...TEXT,
      fontSize: 20,
      lineHeight: 50,
      fontWeight: "bold",
    },
});