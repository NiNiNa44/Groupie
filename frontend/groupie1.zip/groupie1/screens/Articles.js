import * as React from 'react';
import * as Google from 'expo-auth-session/providers/google';
import * as WebBrowser from 'expo-web-browser';
import {
  StyleSheet,
  ViewStyle,
  View,
  Text,
  Image,
  TouchableOpacity,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import data from "./data.js";

const Articles = () => {
return (
	<View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
	<Text style={{ fontSize: 40 }}>Where are we dropping boys?</Text>

	</View>
);
};


export default function Article({ item }) {
  return (
    <View style={styles.article}>
      <View style={styles.header}>
        <View style={styles.user}>
          <TouchableOpacity>
          // replace DATA with item
            <Image source={data.articles.avatar} style={styles.avatar} />
          </TouchableOpacity>

          <TouchableOpacity>
            <Text numberOfLines={1} style={styles.name}>
              {data.articles.name}
            </Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity>
          <Feather name="arrow-right" size={16} />
        </TouchableOpacity>
      </View>

    </View>
  );
}


const ROW: ViewStyle = { flexDirection: "row", alignItems: "center" };

const styles = StyleSheet.create({
  article: {
    marginBottom: 15,
  },
  header: {
    ...ROW,
    justifyContent: "space-between",
    height: 60,
    paddingHorizontal: 16,
  },
  user: {
    ...ROW,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },
  name: {
    textAlign: "center",
    fontSize: 12,
    lineHeight: 14,
    color: "#262626",
    marginLeft: 12,
    fontWeight: "bold",
  },
  image: {
    width: "100%",
    height: null,
    aspectRatio: 1,
    resizeMode: "contain",
    backgroundColor: "red",
    margin: 0,
    padding: 0,
  },
  action: {
    ...ROW,
    justifyContent: "space-between",
    marginTop: 4,
    paddingHorizontal: 8,
  },
  actionLeft: {
    ...ROW,
  },
  actionButton: {
    padding: 8,
  },
  info: {
    paddingHorizontal: 16,
  },
  date: {
    color: "#8e8e8e",
    fontSize: 10,
    marginBottom: 5,
  },
});

